vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Oct 2012 23:50:42 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|18 Oct 2012 23:50:42 -0000
vti_filesize:IR|1120
vti_backlinkinfo:VX|
