vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|22 Nov 2012 00:45:52 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|22 Nov 2012 00:45:52 -0000
vti_filesize:IR|2543
vti_backlinkinfo:VX|
