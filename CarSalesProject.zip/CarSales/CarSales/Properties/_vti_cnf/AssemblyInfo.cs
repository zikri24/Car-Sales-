vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|17 Sep 2012 02:37:32 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|17 Sep 2012 02:37:32 -0000
vti_filesize:IR|1387
vti_backlinkinfo:VX|
