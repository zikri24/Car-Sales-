vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|21 Nov 2012 18:08:20 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|21 Nov 2012 18:08:20 -0000
vti_filesize:IR|3828
vti_backlinkinfo:VX|
