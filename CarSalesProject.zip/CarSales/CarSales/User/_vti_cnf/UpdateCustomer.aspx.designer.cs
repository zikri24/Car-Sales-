vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Oct 2012 04:03:02 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|16 Oct 2012 04:03:02 -0000
vti_filesize:IR|6315
vti_backlinkinfo:VX|
