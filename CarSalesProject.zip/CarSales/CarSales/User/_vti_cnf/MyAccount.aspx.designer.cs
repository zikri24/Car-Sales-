vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|04 Nov 2012 05:17:48 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|04 Nov 2012 05:17:48 -0000
vti_filesize:IR|452
vti_backlinkinfo:VX|
