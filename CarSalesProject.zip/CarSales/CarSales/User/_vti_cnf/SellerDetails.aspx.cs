vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Nov 2012 20:04:13 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|19 Nov 2012 20:04:13 -0000
vti_filesize:IR|1039
vti_backlinkinfo:VX|
