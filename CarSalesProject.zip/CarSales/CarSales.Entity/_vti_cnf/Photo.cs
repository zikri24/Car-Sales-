vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|07 Nov 2012 03:28:10 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|07 Nov 2012 03:28:10 -0000
vti_filesize:IR|336
vti_backlinkinfo:VX|
