vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|07 Nov 2012 03:29:44 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|07 Nov 2012 03:29:44 -0000
vti_filesize:IR|1999
vti_backlinkinfo:VX|
